#pragma strict

var myInt : int = 5;

function MyFunction (number : int) : int
{
    var ret = myInt * number;
    return ret;
}